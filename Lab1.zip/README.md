# Lab1

Laborator 1.

Application requirements:

- an input form
- a list of items
- display a chart
- authentication
- offline support - persist data on the local storage
- online support - synchronize date to/from a remote location
- intent - eg. show map coordinates on google maps, or send 
an email using gmail

The app will present a list of movies. A user will be able to select a movie from the list and add it to his watch later list. After
the movie is seen, the person who saw it can mark it as viewed. The user will be able to see a list of all watch later and all theseen movies.
