package com.example.george.movieapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final String TEST = "test";
    ListView listView ;
    int poz;
    String[] values;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText editText = (EditText) findViewById(R.id.editText);
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                boolean handled = false;
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    handled = true;
                }
                return handled;
            }
        });

        listView = (ListView) findViewById(R.id.list);

        // Defined Array values to show in ListView
        values = new String[] {

                "Closer 2004 Drama,Romance",
                "Gone Girl 2014 Crime,Drama,Mystery",
                "Sausage Party 2016 Animation,Adventure,Comedy",
                "The Girl on the Train 2016 Drama,Mystery,Thriller",
                "Ex Machina 2015 Drama,Mystery,Sci-Fi",
                "Doctor Strange 2016 Action,Adventure,Fantasy,Sci-Fi",
                "Se7en 1995 Crime,Drama,Mystery",
                "The Usual Suspects 1995 Crime,Drama,Mystery",
                "Memento 2000 Mystery,Thriller"

        };

        adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, values);

        // Assign adapter to ListView
        listView.setAdapter(adapter);

        // ListView Item Click Listener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // When clicked, show a toast with the TextView text
                Toast.makeText(getApplicationContext(),
                        ((TextView) view).getText(), Toast.LENGTH_SHORT).show();
                poz = position;
                Intent intent = new Intent(MainActivity.this,ListViewExample.class);
                intent.putExtra("curel",((TextView) view).getText().toString());
                startActivityForResult(intent,1);
            }
        });

        Button but = (Button) findViewById(R.id.but);
        but.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_EMAIL, "valentina.bodron@yahoo.ro");
                intent.putExtra(Intent.EXTRA_SUBJECT, "Item selected from movie list");
                intent.putExtra(Intent.EXTRA_TEXT, editText.getText().toString());
                startActivity(Intent.createChooser(intent, "Send"));
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                String newelem = data.getStringExtra("RESULT_STRING");
                values[poz] = newelem;
                adapter.notifyDataSetChanged();
            }
        }
    }


    @Override
    protected void onRestart() {
        super.onRestart();
        Log.v(TEST,"onRestart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.v(TEST,"onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v(TEST,"onPause");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v(TEST,"onDestroy");
    }


}
